<?php
require_once('../connect.php');

use ClickBlocks\Core,
    ClickBlocks\DB;
    
$sparks = foo(new DB\OrchestraSparkFront())->getAll();
if (is_array($sparks) && count($sparks))
  foreach ($sparks as $sparkArr)
  {
    $spark = foo(new DB\ServiceSparkFront())->getByID($sparkArr['sparkFrontID']);
    $data = json_decode($spark->data, 1);
    print_r($data);
    foreach ($data as $colNum => $col)
    {
      if ($col[9000])
      {
        $x = $data;
        unset($data[$colNum][7500]);
        unset($data[$colNum][8000]);
        unset($data[$colNum][8500]);
        unset($data[$colNum][9000]);

        $data[$colNum][6500] = $x[$colNum][7500];
        $data[$colNum][7000] = $x[$colNum][8000];
        $data[$colNum][7500] = $x[$colNum][8500];
        $data[$colNum][8000] = $x[$colNum][9000];
      }
    }
    $spark->data = json_encode($data);
    foo(new DB\ServiceSparkFront())->save($spark);
  }



  $sparks = foo(new DB\OrchestraSparkRear())->getAll();
if (is_array($sparks) && count($sparks))
  foreach ($sparks as $sparkArr)
  {
    $spark = foo(new DB\ServiceSparkRear())->getByID($sparkArr['sparkRearID']);
    $data = json_decode($spark->data, 1);
    print_r($data);
    foreach ($data as $colNum => $col)
    {
      if ($col[9000])
      {
        $x = $data;
        unset($data[$colNum][7500]);
        unset($data[$colNum][8000]);
        unset($data[$colNum][8500]);
        unset($data[$colNum][9000]);

        $data[$colNum][6500] = $x[$colNum][7500];
        $data[$colNum][7000] = $x[$colNum][8000];
        $data[$colNum][7500] = $x[$colNum][8500];
        $data[$colNum][8000] = $x[$colNum][9000];
      }
    }
    $spark->data = json_encode($data);
    foo(new DB\ServiceSparkRear())->save($spark);
  }