<?php
require_once('../connect.php');

use ClickBlocks\Core,
    ClickBlocks\DB;
    
$mapStructure = getMapStructure('2011');
foreach ($mapStructure as $k => $v)
{
  $labels[] = $k;
  $offsets[] = $v['offset'];
  $sectorOffsets[] = $v['sectorOffset'];
  $columns[] = $v['columns'];
  $hiddenColumns[] = $v['hiddenColumns'];
  $rows[] = $v['rows'];
}
  

$file_handle = fopen(dirname(__FILE__) . "/2011_tune.txt", "rb"); 

$ln = '<br/>';
function h1($file, $sectorOffset, $offset, $dataSize, $c=1)
{
  fseek($file, $sectorOffset*256+$offset);
  return chunk_split(bin2hex(fread($file, $dataSize)),2*$c,' ');
}

$f = fopen(dirname(__FILE__) . '/2011_tune.txt', 'rb');
echo "Engine Displacement: $ln"; 
echo h($f, 0x09, 172, 2, 2)." = ";
echo base_convert("0x".h($f, 0x09, 172, 2, 2), 16,10)/262 . $ln;

echo "IAC Warmup Steps: $ln"; 
echo h($f, 0x0D, 195, 12, 1).$ln;


echo $ln;

echo "=================================================================";
foreach ($mapStructure as $k => $v)
{
  echo "$ln $ln" . $k . ": $ln";
  if ($k == 'EngineDisplacement')
    $d = 2;
  else
    $d = 1;  
  try 
  {
    $data = h($f, $v['sectorOffset'], $v['offset'], $v['dataSize'], $d);
    echo $data . " = ";
    if ($k == 'EngineDisplacement')
    {
      $ed = base_convert("0x".h($f, $v['sectorOffset'], $v['offset'], $v['dataSize'], $d), 16,10)/262;
      echo $ed . $ln;  
      $arrayValues['EngineDisplacement'] = $ed;
    }
    else
    {
      $bytes = explode(' ', $data);
      if (is_array($bytes) && count($bytes))
        if ($v['dataType'] == 'table')
        {
          echo $ln;
          $i = 0;
          foreach ($bytes as $bNum => $byte)
          {
            if (!$byte || !isset($v['table']['titles']['values'][$i]))
              continue;
            if ($v['divider'])
              $divider = $v['divider'];
            else
              $divider = 1;
            if ($v['factor'])
              $factor = $v['factor'];
            else
              $factor = 1;            
            $val = round($factor * base_convert("0x" . $byte, 16,10) / $divider, 2);
            $arrayValues[$v['DBTableName']][$v['table']['titles']['values'][$i]] = $val;
            echo $v['table']['titles']['values'][$i] . ' = ' . $val . $ln;             
            $i++;
          }  

        }
        elseif ($v['dataType'] == 'matrix')
        {
          $k = 0;
          foreach ($bytes as $byte) 
          {
            # code...
          }
          for ($ii = 0; $ii < $v['rows']; $ii++)
          {
            for ($j = 0; $j < $v['cols']; $j++)
            {
              if ($k == 0)
                echo $ln;
              $val = base_convert("0x" . $bytes[$k + $ii*$v['cols'] + $ii*$v['padding']], 16,10);
              $arrayValues[$v['DBTableName']][$v['axis']['X']['values'][$j]][$v['axis']['Y']['values'][$ii]] = $val;
              print_r($val . ' ');
              $k++;
            }
            $k = 0;
          }
        }
        else
          foreach ($bytes as $byte)
            echo base_convert("0x" . $byte, 16,10) . $ln;     
    }
      
  } 
  catch (\Exception $e) 
  {
     
  } 
  print_r($arrayValues);
}
