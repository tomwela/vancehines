<?php
require_once('../connect.php');

use ClickBlocks\Core,
    ClickBlocks\DB;
    
$file_handle = fopen(dirname(__FILE__) . "/tune.txt", "rb"); 
//Read engine displacements
 
fseek($file_handle, (hexdec(0x09)) * 256 + 172);
$ed = fread($file_handle, 2);
print_r('Engine displacement <br/>');
echo "=======================================<br/>";
print_r('BIN: ' . $ed . '<br />'); 
print_r('HEX: ' . bin2hex($ed) . '<br />');
print_r('DEC: ' . $val = hexdec(bin2hex($ed)) . '<br />'); 
print_r('VALUE: ' . $val / 262 . '<br />');
echo "---------------------------------------<br/>";

//Read IAC warmup steps
fseek($file_handle, hexdec(0x0D) * 256 + 195);
for ($i = 1; $i <= 12; $i++)
{
  $iac[$i] = fread($file_handle, 1);
}
foreach ($iac as $p)
{
  $iacb .= '<tr><td>' . $p . '</td></tr>';
  $iach .= '<tr><td>' . bin2hex($p) . '</td></tr>';
  $iacd .= '<tr><td>' . hexdec(bin2hex($p)) . '</td></tr>';
} 
$iacb = '<table>' . $iacb . '</table>';
$iach = '<table>' . $iach . '</table>';
$iacd = '<table>' . $iacd . '</table>';

print_r('IAC Warmup Steps <br/>');
echo "=======================================<br/>";
$text = '
  <table border="1">
    <tr>
      <td>
        BIN
      </td>
      <td>
        HEX
      </td>
      <td>
        DEC
      </td>
    </tr>
    <tr>
      <td>
        ' . $iacb . '
      </td>
      <td>
        ' . $iach . '
      </td>
      <td>
        ' . $iacd . '
      </td>
    </tr>    
  </table>
';
 print_r($text);
//print_r('BIN: ' . $iacb . '<br />'); 
//print_r('HEX: ' . $iach . '<br />');
//print_r('DEC: ' . $iacd . '<br />'); 

echo "---------------------------------------<br/>";

//Read IDLE RPM
fseek($file_handle, hexdec(0x0D) * 256 + 183);
for ($i = 1; $i <= 12; $i++)
{
  $idle[$i] = fread($file_handle, 1);
}
foreach ($iac as $p)
{
  $idleb .= '<tr><td>' . $p . '</td><tr/>';
  $idleh .= '<tr><td>' . bin2hex($p) . '</td><tr/>';
  $idled .= '<tr><td>' . hexdec(bin2hex($p)) . '</td><tr/>';
} 
$idleb = '<table>' . $idleb . '</table>';
$idleh = '<table>' . $idleh . '</table>';
$idled = '<table>' . $idled . '</table>';

print_r('IDLE RPM <br/>');
echo "=======================================<br/>";
$text = '
  <table border="1">
    <tr>
      <td>
        BIN
      </td>
      <td>
        HEX
      </td>
      <td>
        DEC
      </td>
    </tr>
    <tr>
      <td>
        ' . $idleb . '
      </td>
      <td>
        ' . $idleh . '
      </td>
      <td>
        ' . $idled . '
      </td>
    </tr>    
  </table>
';
 print_r($text);
//print_r('BIN: ' . $idleb . '<br />'); 
//print_r('HEX: ' . $idleh . '<br />');
//print_r('DEC: ' . $idled . '<br />'); 

echo "---------------------------------------<br/>";


//Read VE Front Cyl
fseek($file_handle, hexdec(0x0D) * 256 + 183);
for ($i = 1; $i <= 12; $i++)
{
  $idle[$i] = fread($file_handle, 1);
}
foreach ($iac as $p)
{
  $idleb .= '<tr><td>' . $p . '</td><tr/>';
  $idleh .= '<tr><td>' . bin2hex($p) . '</td><tr/>';
  $idled .= '<tr><td>' . hexdec(bin2hex($p)) . '</td><tr/>';
} 
$idleb = '<table>' . $idleb . '</table>';
$idleh = '<table>' . $idleh . '</table>';
$idled = '<table>' . $idled . '</table>';

print_r('VE Front Cyl <br/>');
echo "=======================================<br/>";
$text = '
  <table border="1">
    <tr>
      <td>
        BIN
      </td>
      <td>
        HEX
      </td>
      <td>
        DEC
      </td>
    </tr>
    <tr>
      <td>
        ' . $idleb . '
      </td>
      <td>
        ' . $idleh . '
      </td>
      <td>
        ' . $idled . '
      </td>
    </tr>    
  </table>
';
 print_r($text);
echo "---------------------------------------<br/>";


?>